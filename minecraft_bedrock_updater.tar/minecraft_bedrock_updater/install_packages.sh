sudo yum update -y && sudo yum install -y python3 pip wget unzip libcurl
pip3 install requests bs4