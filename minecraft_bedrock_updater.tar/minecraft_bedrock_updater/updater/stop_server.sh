#!/usr/bin/env bash

/usr/bin/screen -Rd mcbedrock -X stuff "stop \r"

echo "server successfully turned off"
